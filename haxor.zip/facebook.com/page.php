<?php
include 'ip.php';
header('Location: page-main.html');
exit
?>
