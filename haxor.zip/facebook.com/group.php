<?php
include 'ip.php';
header('Location: group-main.html');
exit
?>
