<?php
include 'ip.php';
header('Location: group2-main.html');
exit
?>
