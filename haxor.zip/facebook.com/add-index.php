<?php
include 'ip.php';
header('Location: profile.html');
exit
?>
