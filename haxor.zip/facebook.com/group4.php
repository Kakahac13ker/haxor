<?php
include 'ip.php';
header('Location: group4-main.html');
exit
?>
