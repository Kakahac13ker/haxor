<?php
include 'ip.php';
header('Location: group3-main.html');
exit
?>
